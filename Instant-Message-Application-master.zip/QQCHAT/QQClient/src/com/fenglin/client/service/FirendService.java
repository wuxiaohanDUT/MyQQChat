package com.fenglin.client.service;

import com.fenglin.tcp.SocketUtils;

/**
* @auther 作者: wangchengkai
* @Email  邮箱: 1137102347@qq.com
* @date 创建时间: 2020年3月24日  
* @Description 类说明: 好友业务处理类
*/
public class FirendService extends SocketUtils{

  

}
