package com.fenglin.client.service;

import com.fenglin.tcp.SocketUtils;

public class UserService extends SocketUtils{
	
	 
}
