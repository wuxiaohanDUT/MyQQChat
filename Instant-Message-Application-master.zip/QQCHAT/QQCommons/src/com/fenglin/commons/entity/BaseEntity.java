package com.fenglin.commons.entity;

import java.io.Serializable;

public class BaseEntity   implements Serializable{

	 
	private static final long serialVersionUID = -8770042974456581739L;

	 

}
