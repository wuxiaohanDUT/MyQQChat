# Instant-Message-Application
本项目属于即时通讯app,仿造QQ相关功能开发的,采用java开发语言,利用socket和swing实现项目搭建. 项目功能有聊天通讯 表情发送, 文件传送,视频电话等功能, 项目共有,commons公共模块,单点登录sso模块, server后台模块, 消息中转服务器,客户端等模块组成
