package com.fenglin.server;

import com.fenglin.server.view.ServerView;

public class ServerApplication {

	public static void main(String[] args) {
		ServerView serverView = new ServerView();
		serverView.createFrame();
	}
}
